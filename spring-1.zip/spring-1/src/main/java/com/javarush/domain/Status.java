package com.javarush.domain;

public enum Status {
    IN_PROGRESS,
    DONE,
    PAUSED
}

